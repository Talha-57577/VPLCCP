﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using VPLAssistPlus.Data;
using VPLAssistPlus.Models;

namespace VPLAssistPlus
{
    public partial class MainWindow : Window
    {
        private readonly StudentRepository _repo;
        private ObservableCollection<Student> _students = new ObservableCollection<Student>();

        public MainWindow()
        {
            InitializeComponent();

            string filePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "students.json");
            _repo = new StudentRepository(filePath);
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cmbProgram.ItemsSource = new List<string> { "BSCS", "BSE", "BBA", "BSIT" };
            cmbProgram.SelectedIndex = 0;

            await LoadStudentsAsync();
        }

        // MULTITHREADING: Load data without freezing UI
        private async Task LoadStudentsAsync()
        {
            ToggleUI(false);
            lblStatus.Text = "Loading...";

            try
            {
                var loaded = await Task.Run(() => _repo.Load()); // background thread
                _students = new ObservableCollection<Student>(loaded);
                dgStudents.ItemsSource = _students;
                UpdateSummary();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load: " + ex.Message);
            }
            finally
            {
                lblStatus.Text = "";
                ToggleUI(true);
            }
        }

        private async Task SaveAsync()
        {
            try
            {
                // Save in background thread
                await Task.Run(() => _repo.Save(_students.ToList()));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save: " + ex.Message);
            }
        }

        private void ToggleUI(bool enabled)
        {
            btnAdd.IsEnabled = enabled;
            btnUpdate.IsEnabled = enabled;
            btnDelete.IsEnabled = enabled;
            btnClear.IsEnabled = enabled;
            btnSearch.IsEnabled = enabled;
            btnReset.IsEnabled = enabled;
        }

        private bool TryGetInputs(out Student s)
        {
            s = new Student();

            if (!int.TryParse(txtId.Text.Trim(), out int id))
            {
                MessageBox.Show("Invalid ID. Enter a number.");
                return false;
            }

            string name = txtName.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Name cannot be empty.");
                return false;
            }

            if (!double.TryParse(txtMarks.Text.Trim(), out double marks))
            {
                MessageBox.Show("Invalid marks. Enter numeric value.");
                return false;
            }

            if (marks < 0 || marks > 100)
            {
                MessageBox.Show("Marks must be 0 to 100.");
                return false;
            }

            s.Id = id;
            s.Name = name;
            s.Program = cmbProgram.SelectedItem?.ToString() ?? "";
            s.Marks = marks;
            return true;
        }

        private async void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (!TryGetInputs(out Student s)) return;

            if (_students.Any(x => x.Id == s.Id))
            {
                MessageBox.Show("This ID already exists.");
                return;
            }

            _students.Add(s);
            UpdateSummary();
            await SaveAsync();
            ClearInputs();
        }

        private async void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (dgStudents.SelectedItem == null)
            {
                MessageBox.Show("Select a student to update.");
                return;
            }

            if (!TryGetInputs(out Student updated)) return;

            Student selected = (Student)dgStudents.SelectedItem;

            // If ID changed, ensure uniqueness
            if (updated.Id != selected.Id && _students.Any(x => x.Id == updated.Id))
            {
                MessageBox.Show("New ID already exists.");
                return;
            }

            selected.Id = updated.Id;
            selected.Name = updated.Name;
            selected.Program = updated.Program;
            selected.Marks = updated.Marks;

            dgStudents.Items.Refresh();
            UpdateSummary();
            await SaveAsync();
        }

        private async void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgStudents.SelectedItem == null)
            {
                MessageBox.Show("Select a student to delete.");
                return;
            }

            Student selected = (Student)dgStudents.SelectedItem;

            var result = MessageBox.Show($"Delete {selected.Name}?",
                "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes) return;

            _students.Remove(selected);
            UpdateSummary();
            await SaveAsync();
            ClearInputs();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e) => ClearInputs();

        private void ClearInputs()
        {
            txtId.Text = "";
            txtName.Text = "";
            txtMarks.Text = "";
            cmbProgram.SelectedIndex = 0;
        }

        private void DgStudents_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgStudents.SelectedItem == null) return;

            Student s = (Student)dgStudents.SelectedItem;
            txtId.Text = s.Id.ToString();
            txtName.Text = s.Name;
            txtMarks.Text = s.Marks.ToString();
            cmbProgram.SelectedItem = s.Program;
        }

        // MULTITHREADING: Search on background thread
        private async void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string term = txtSearch.Text.Trim().ToLower();
            if (string.IsNullOrWhiteSpace(term))
            {
                MessageBox.Show("Enter search text (name or program).");
                return;
            }

            ToggleUI(false);
            lblStatus.Text = "Searching...";

            try
            {
                var results = await Task.Run(() =>
                    _students.Where(s =>
                        s.Name.ToLower().Contains(term) ||
                        s.Program.ToLower().Contains(term)
                    ).ToList()
                );

                dgStudents.ItemsSource = new ObservableCollection<Student>(results);
                lblStatus.Text = $"Found: {results.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Search failed: " + ex.Message);
            }
            finally
            {
                ToggleUI(true);
            }
        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            dgStudents.ItemsSource = _students;
            lblStatus.Text = "";
            UpdateSummary();
        }

        private void UpdateSummary()
        {
            lblTotal.Text = $"Total Students: {_students.Count}";

            if (_students.Count == 0)
            {
                lblAverage.Text = "Average Marks: N/A";
                return;
            }

            double avg = _students.Average(s => s.Marks);
            lblAverage.Text = $"Average Marks: {avg:F2}";
        }
    }
}
