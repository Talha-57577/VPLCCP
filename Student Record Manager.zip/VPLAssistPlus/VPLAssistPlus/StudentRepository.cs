﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using VPLAssistPlus.Models;

namespace VPLAssistPlus.Data
{
    public class StudentRepository
    {
        private readonly string _filePath;

        public StudentRepository(string filePath)
        {
            _filePath = filePath;
        }

        public List<Student> Load()
        {
            try
            {
                if (!File.Exists(_filePath))
                    return new List<Student>();

                string json = File.ReadAllText(_filePath);
                var data = JsonConvert.DeserializeObject<List<Student>>(json);
                return data ?? new List<Student>();
            }
            catch
            {
                return new List<Student>();
            }
        }

        public void Save(List<Student> students)
        {
            try
            {
                string json = JsonConvert.SerializeObject(students, Formatting.Indented);
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex)
            {
                throw new Exception("Could not save file: " + ex.Message);
            }
        }
    }
}
