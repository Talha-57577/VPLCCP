﻿namespace VPLAssistPlus.Models
{
    public class Student
    {
        public int Id { get; set; }          // unique
        public string Name { get; set; }
        public string Program { get; set; }
        public double Marks { get; set; }

        public Student()
        {
            Name = "";
            Program = "";
        }

        public Student(int id, string name, string program, double marks)
        {
            Id = id;
            Name = name ?? "";
            Program = program ?? "";
            Marks = marks;
        }

        public override string ToString()
        {
            return Id + " - " + Name + " (" + Program + ") : " + Marks;
        }
    }
}
